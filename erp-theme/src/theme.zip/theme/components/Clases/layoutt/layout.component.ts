import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['../../../stylesStorybook/_clases.scss'],
})
export class LayoutComponent {
  @Input() items!: string;
  @Input() grid!: string;
  @Input() flex!: string;
  @Input() column!: string;
  @Input() justify!: string;

  public get custom(): string[] {
    return [
      `${this.items}`,
      `${this.grid}`,
      `${this.flex}`,
      `${this.column}`,
      `${this.justify}`,
    ];
  }
}
